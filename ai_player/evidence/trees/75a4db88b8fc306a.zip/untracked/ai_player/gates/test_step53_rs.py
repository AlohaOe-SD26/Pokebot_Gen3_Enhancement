"""TEST SIDE (build step 5.3, queue item 3 (4): THE RE-SOURCING BUILD, builder 1): the re-sourced checks of `rate_step5.py`,
each graded by the GAME or the HARNESS alone (USER RULING 35), and the development-only RE-GRADE.

    py -3.12 ai_player/gates/test_step53_rs.py        (unittest; offline, no ROM, about 2 s)

The plan these tests prove is `PROJECT KNOWLEDGE/ai-research-notes/2026-10-25-step5.3-resourcing-plan.md` (its items are the
A2 decision addendum's work list). Every rule has a FAULT arm (the rule broken: the check must FAIL) and a CONTROL arm (the
healthy path passes), and each guard's call-deleting mutant is caught here (the builder's report lists them):
  TrainedTests      item 1: R5.CH1_TRAINED by the tall-grass steps (Story floor; Trainer/Catcher paired with NOTRAIN) and
                    R5.NOTRAIN_TRAINED_CHECK (NOTRAIN's Story runs under the floor); the AI's windows are no longer read.
  StallTests        item 2: R5.STALL and STALL1-3 by the game's wait path alone.
  BeelineTests      item 3: R5.OFF_BEELINE on the game's stood tiles.
  NoSpeedrunTests   item 4: R5.NO_SPEEDRUN_DICE on the game's frames to the POKéDEX less the game's battle frames.
  Lose3Tests        item 6: R5.LOSE3's game/harness half (a floor of 2 runs that reached the cap) and R5.LOSE3_WORD.
  PatienceTests     item 7: R5.PATIENCE on the dex half alone.
  DetourTests       item 16(a): arrival judged over [end - slack, end], never after the end.
  RegradeTests      part C: a re-grade refuses every purpose but `regrade` and every source but a finished development
                    entry; a re-grade of a synthetic kept folder equals the original grade; the control arms.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from ai_player.gates import grader_checks as gc  # noqa: E402
from ai_player.gates import rate_step5 as rs  # noqa: E402
from ai_player.gates.test_step53_a1 import grade_sweep, row, sweep  # noqa: E402

BOUNDS = rs.BOUNDS


def status(results, check_id: str) -> str:
    found = [c for c in results if c.id == check_id]
    assert len(found) == 1, (check_id, [c.id for c in results])
    return found[0].status


def grass_rows(ch1: dict[int, tuple[str, int]], notrain: dict[int, tuple[str, int]]) -> dict[str, list[dict]]:
    """CH1 and NOTRAIN rows whose only difference is the GAME's grass steps before the rival, per seed (personality, steps)."""
    return {"CH1": [row("CH1", s, p, grass_before_rival=g) for s, (p, g) in ch1.items()],
            "NOTRAIN": [row("NOTRAIN", s, p, grass_before_rival=g) for s, (p, g) in notrain.items()]}


#: ledger #39's grass steps before the rival (the measure json), per seed: CH1 and NOTRAIN
#: (read back from the kept folders by this build's re-grade, `2026-10-25-step53rs1-REGRADE.txt`)
DEV_CH1 = {1307: ("Catcher", 168), 1308: ("Trainer", 254), 1309: ("Story", 177), 1310: ("Catcher", 196),
           1311: ("Trainer", 373), 1312: ("Story", 120), 1313: ("Catcher", 122), 1314: ("Trainer", 278),
           1315: ("Story", 106), 1316: ("Catcher", 185), 1317: ("Trainer", 265), 1318: ("Story", 102)}
DEV_NO = {1307: ("Catcher", 124), 1308: ("Trainer", 124), 1309: ("Story", 32), 1310: ("Catcher", 144),
          1311: ("Trainer", 128), 1312: ("Story", 23), 1313: ("Catcher", 99), 1314: ("Trainer", 150),
          1315: ("Story", 38), 1316: ("Catcher", 150), 1317: ("Trainer", 151), 1318: ("Story", 37)}


class TrainedTests(unittest.TestCase):
    def trained(self, ch1, notrain) -> tuple[str, str]:
        results = grade_sweep(grass_rows(ch1, notrain))
        return status(results, "R5.CH1_TRAINED"), status(results, "R5.NOTRAIN_TRAINED_CHECK")

    def test_the_development_rows_pass_and_notrain_fails_the_story_floor(self):
        self.assertEqual(self.trained(DEV_CH1, DEV_NO), (gc.PASS, gc.PASS))  # CONTROL

    def test_a_story_run_under_the_floor_fails(self):
        low = {**DEV_CH1, 1309: ("Story", 38)}
        self.assertEqual(self.trained(low, DEV_NO)[0], gc.FAIL)  # FAULT: 38 steps
        edge = {**DEV_CH1, 1309: ("Story", BOUNDS["TRAINED_GRASS_STORY_MIN"])}
        self.assertEqual(self.trained(edge, DEV_NO)[0], gc.PASS)  # CONTROL: at the floor passes

    def test_a_pooled_ratio_of_one_fails_trainer_and_catcher(self):
        for personality in ("Trainer", "Catcher"):
            with self.subTest(personality=personality):
                same = {s: (p, DEV_NO[s][1] if p == personality else g) for s, (p, g) in DEV_CH1.items()}
                self.assertEqual(self.trained(same, DEV_NO)[0], gc.FAIL)  # FAULT: CH1 == NOTRAIN

    def test_the_share_fails_when_ch1_is_above_notrain_on_under_half_the_seeds(self):
        # six Trainer seeds: CH1 far above on 2 (pooled well over 1.3), just under on 4 -> 2 of 6 < 50 %
        ch1 = {1: ("Trainer", 900), 2: ("Trainer", 900), 3: ("Trainer", 140), 4: ("Trainer", 140), 5: ("Trainer", 140),
               6: ("Trainer", 140)}
        no = {s: ("Trainer", 150) for s in ch1}
        self.assertEqual(self.trained(ch1, no)[0], gc.FAIL)  # FAULT: the share
        ch1[3] = ("Trainer", 160)  # 3 of 6 above: exactly the 50 % share
        self.assertEqual(self.trained(ch1, no)[0], gc.PASS)  # CONTROL

    def test_the_stall2_1308_shape_passes_under_the_paired_rule(self):
        # a Trainer seed walking 139 against its own NOTRAIN's 124 (under another seed's NOTRAIN 151): paired, it passes
        shape = {**DEV_CH1, 1308: ("Trainer", 139), 1308 + 100: ("Trainer", 300)}
        no = {**DEV_NO, 1308: ("Trainer", 124), 1308 + 100: ("Trainer", 151)}
        self.assertEqual(self.trained(shape, no)[0], gc.PASS)  # CONTROL

    def test_a_personality_with_runs_but_no_pair_never_passes(self):
        no = {s: v for s, v in DEV_NO.items() if v[0] != "Catcher"}
        self.assertEqual(self.trained(DEV_CH1, no)[0], gc.FAIL)  # FAULT: Catcher unjudgeable

    def test_the_ais_training_windows_are_no_longer_read(self):
        rows = grass_rows(DEV_CH1, DEV_NO)
        for r in rows["CH1"]:
            r.update(game_train_steps=0, game_train_won=0, train_steps_before_rival=0, train_windows=0, rival_judge=None)
        self.assertEqual(status(grade_sweep(rows), "R5.CH1_TRAINED"), gc.PASS)  # the AI's records say nothing now

    def test_notrain_at_the_story_floor_fails_the_control_check(self):
        no = {**DEV_NO, 1309: ("Story", BOUNDS["TRAINED_GRASS_STORY_MIN"])}
        self.assertEqual(self.trained(DEV_CH1, no)[1], gc.FAIL)  # FAULT: the control met the floor
        none = {s: v for s, v in DEV_NO.items() if v[0] != "Story"}
        self.assertEqual(self.trained(DEV_CH1, {**none, **{s: v for s, v in DEV_NO.items() if v[0] == "Story"}})[1],
                         gc.PASS)  # CONTROL

    def test_notrain_against_itself_fails_by_construction(self):
        rule = rs.paired_rule(grass_rows(DEV_NO, DEV_NO)["CH1"], grass_rows(DEV_NO, DEV_NO)["NOTRAIN"], "Trainer")
        self.assertEqual((rule["pooled"], rule["above"], rule["ok"]), (1.0, 0, False))

    def test_the_grass_read_counts_tall_grass_between_the_marks(self):
        data = {"story": {"changes": [{"mark": "VAR_BIRCH_LAB_STATE", "to": 2, "f": 100},
                                      {"mark": "DEFEATED_RIVAL_ROUTE103", "to": 1, "f": 900}]},
                "game_reads": {"tiles": {"steps": [[50, "0:16", 1, 1, "Tall Grass"], [200, "0:16", 1, 2, "Tall Grass"],
                                                   [300, "0:16", 1, 3, "Normal"], [900, "0:16", 1, 4, "Tall Grass"],
                                                   [901, "0:16", 1, 5, "Tall Grass"]]}}}
        self.assertEqual(rs.grass_before_rival(data), 2)  # 200 and 900: after the starter's mark, up to the flag
        self.assertIsNone(rs.grass_before_rival({**data, "game_reads": {}}))  # no tile read: not judged
        self.assertEqual(rs.grass_stint(data), 700)


class StallTests(unittest.TestCase):
    def test_a_real_run_at_the_bound_by_the_game_fails(self):
        rows = sweep()
        rows["NOHINTS"][0]["await_game_max"] = BOUNDS["AWAIT_MAX"]
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.STALL"), gc.FAIL)  # FAULT
        self.assertEqual(status(rs.step51_verdicts(sweep()), "R5.STALL"), gc.PASS)  # CONTROL

    def test_the_ais_record_is_no_longer_read(self):
        rows = sweep()
        rows["CH1"][0]["await_ai_max"] = 900  # the AI's path alone over the bound
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.STALL"), gc.PASS)

    def test_a_stall_arm_fails_only_by_the_games_path(self):
        for plan in ("STALL1", "STALL2", "STALL3"):
            with self.subTest(plan=plan):
                rows = sweep()
                rows[plan] = [row(plan, s, await_ai_max=600, await_game_max=150) for s in (1, 2)]
                self.assertEqual(status(rs.step51_verdicts(rows), f"R5.{plan}"), gc.FAIL)  # FAULT: every game value 150
                rows[plan][1].update(await_ai_max=0, await_game_max=600)
                self.assertEqual(status(rs.step51_verdicts(rows), f"R5.{plan}"), gc.PASS)  # CONTROL: one by the game


class BeelineTests(unittest.TestCase):
    def test_ch1_on_the_beeline_by_the_game_fails(self):
        rows = sweep()
        corridor = set().union(*(r["_stood"] for r in rows["ERRANDS_OFF"]))
        for r in rows["CH1"]:
            r["_stood"] = set(list(corridor)[:2])  # the game: only tiles a beeline run stood on (its AI memory wide)
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.OFF_BEELINE"), gc.FAIL)  # FAULT
        self.assertEqual(status(rs.step51_verdicts(sweep()), "R5.OFF_BEELINE"), gc.PASS)  # CONTROL

    def test_the_ais_world_memory_is_no_longer_read(self):
        rows = sweep()
        for r in rows["CH1"]:
            r["_tiles"] = set()  # the AI's memory says nothing off the beeline; the game says plenty
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.OFF_BEELINE"), gc.PASS)

    def test_a_control_run_counts_against_the_other_control_runs(self):
        rows = sweep()
        found = rs.off_beeline(rs.on_game_tiles(rows["CH1"]), rs.on_game_tiles(rows["ERRANDS_OFF"]))
        self.assertEqual(set(found["control"].values()), {1})  # its own OFFn tile: not zeroed by itself

    def test_game_stood_reads_moves_steps_and_start(self):
        data = {"places": {"moves": [[10, "0:9", 1, 1]]},
                "game_reads": {"tiles": {"start": [0, "0:9", 0, 0, "Normal"], "steps": [[20, "0:9", 2, 2, "Normal"]]}}}
        self.assertEqual(rs.game_stood(data), {"0:9 0,0", "0:9 1,1", "0:9 2,2"})


class NoSpeedrunTests(unittest.TestCase):
    def test_a_ratio_of_one_fails(self):
        rows = sweep()
        for r in rows["ERRANDS_OFF"]:
            r["dex_game"] = dict(rows["CH1"][0]["dex_game"])
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.NO_SPEEDRUN_DICE"), gc.FAIL)  # FAULT
        self.assertEqual(status(rs.step51_verdicts(sweep()), "R5.NO_SPEEDRUN_DICE"), gc.PASS)  # CONTROL

    def test_a_run_slower_only_by_its_battles_fails(self):
        def data(dex_f, battles):
            return {"story": {"changes": [{"mark": "RECEIVED_POKEDEX_FROM_BIRCH", "to": 1, "f": dex_f}]},
                    "places": {"every": 10, "battles": battles}}

        ch1 = rs.frames_to_mark(data(140000, [[10000, 29990]]), "RECEIVED_POKEDEX_FROM_BIRCH")
        off = rs.frames_to_mark(data(120000, []), "RECEIVED_POKEDEX_FROM_BIRCH")
        self.assertEqual((ch1["no_battle"], off["no_battle"]), (120000, 120000))
        rows = sweep()
        for r in rows["CH1"]:
            r["dex_game"] = ch1
        for r in rows["ERRANDS_OFF"]:
            r["dex_game"] = off
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.NO_SPEEDRUN_DICE"), gc.FAIL)  # FAULT: battles subtracted

    def test_the_ais_digests_are_no_longer_read(self):
        rows = sweep()
        for r in rows["CH1"]:
            r["time"] = {"outside_nb": 1, "battles": 0}  # the AI's own digests say it beelined
        self.assertEqual(status(rs.step51_verdicts(rows), "R5.NO_SPEEDRUN_DICE"), gc.PASS)

    def test_a_target_confirmed_only_at_the_end(self):
        data = {"story": {"changes": [], "frames": 5000}, "story_truth": {"marks": {"VAR_PETALBURG_GYM_STATE": 2}},
                "start_story": {"marks": {"VAR_PETALBURG_GYM_STATE": 1}}, "places": {"battles": []}}
        self.assertEqual(rs.frames_to_mark(data, "VAR_PETALBURG_GYM_STATE", 2)["at_end"], True)
        data["start_story"]["marks"]["VAR_PETALBURG_GYM_STATE"] = 2  # it held the mark when it began: not reached here
        self.assertIsNone(rs.frames_to_mark(data, "VAR_PETALBURG_GYM_STATE", 2))


def lose3(*shapes) -> list[dict]:
    """LOSE3 rows: (seed, the game's losses, frames from its last loss to the run's end, reason, report)."""
    want = "play: stuck: 3 battles lost (MAX_LOSSES 3)"
    return [row("LOSE3", s, "Catcher", losses_game=g, losses_ai=rep, losses_told=rep, last_loss_f=1000, frames=1000 + after,
                reason=reason or want, max_losses=3) for s, g, after, reason, rep in shapes]


class Lose3Tests(unittest.TestCase):
    def check(self, rows, check_id="R5.LOSE3") -> str:
        return status(rs.step51_verdicts({"LOSE3": rows}), check_id)

    def test_the_development_shape_passes_and_a_late_end_fails(self):
        dev = [(1307, 3, 655, None, 3), (1310, 3, 651, None, 3), (1313, 2, 200000, "play: stuck: no progress", 2),
               (1316, 3, 664, None, 3)]
        self.assertEqual(self.check(lose3(*dev)), gc.PASS)  # CONTROL: 1313 never reached the cap: left out of n
        late = dev[:1] + [(1310, 3, rs.STOP_WITHIN + 1, None, 3)] + dev[2:]
        self.assertEqual(self.check(lose3(*late)), gc.FAIL)  # FAULT: 6,001 frames after the third loss

    def test_a_loss_past_the_cap_fails(self):
        self.assertEqual(self.check(lose3((1, 3, 600, None, 3), (2, 4, 600, None, 4))), gc.FAIL)  # FAULT: went on

    def test_under_the_floor_is_vacuous(self):
        self.assertEqual(self.check(lose3((1, 3, 600, None, 3), (2, 2, 9000, "x", 2))), gc.VACUOUS)  # 1 of floor 2
        self.assertEqual(self.check(lose3((1, 3, 600, None, 3), (2, 3, 600, None, 3))), gc.PASS)

    def test_the_ai_half_is_honesty(self):
        good = lose3((1, 3, 600, None, 3), (2, 3, 600, None, 3))
        self.assertEqual(self.check(good, "R5.LOSE3_WORD"), gc.PASS)  # CONTROL
        self.assertEqual(gc.CHECKS["R5.LOSE3_WORD"].kind, gc.HONESTY)
        no_cap = lose3((1, 3, 600, "play: stuck: no progress for 9 frames", 3), (2, 3, 600, None, 3))
        self.assertEqual(self.check(no_cap, "R5.LOSE3_WORD"), gc.FAIL)  # FAULT: a reason without the cap
        self.assertEqual(self.check(no_cap), gc.PASS)  # ... which the graded half no longer reads
        wrong = lose3((1, 3, 600, None, 2), (2, 3, 600, None, 3))
        self.assertEqual(self.check(wrong, "R5.LOSE3_WORD"), gc.FAIL)  # FAULT: a report of 2 against the game's 3


class PatienceTests(unittest.TestCase):
    def check(self, reached: list[bool]) -> str:
        rows = {"PATIENCE": [row("PATIENCE", s, "Trainer", reached=ok, train_span=0) for s, ok in enumerate(reached)]}
        return status(rs.step51_verdicts(rows), "R5.PATIENCE")

    def test_the_dex_share(self):
        self.assertEqual(self.check([True] * 4), gc.PASS)  # CONTROL: the dev rows (and the AI's span 0 is not read)
        self.assertEqual(self.check([True] * 4 + [False] * 2), gc.PASS)  # CONTROL: 4 of 6
        self.assertEqual(self.check([True] * 3 + [False] * 3), gc.FAIL)  # FAULT: 3 of 6
        self.assertEqual(self.check([False] * 4), gc.FAIL)  # FAULT: PATIENCE_OLD's shape graded as PATIENCE


class DetourTests(unittest.TestCase):
    RECORDS = [{"decision": "goal", "action": "detour", "frame": 84159},
               {"decision": "goal_end", "action": "detour", "frame": 84492, "reason": "reached the frontier at (0, 10)",
                "extra": {"yield": {"productive": True, "place": ["0:10", 0, 10, "frontier"]}}},
               {"decision": "watch", "frame": 84600}]

    def test_an_end_on_the_place_reads_arrived_though_a_scene_moved_it_after(self):
        # NOTRAIN 1318: on (0, 10) from 84485 to 84510, moved to (1, 10) at 84511 (19 frames after the end)
        data = {"places": {"moves": [[84490, "0:10", 0, 10], [84520, "0:10", 1, 10]]},
                "game_reads": {"tiles": {"start": [0, "0:10", 5, 5, "Normal"],
                                         "steps": [[84485, "0:10", 0, 10, "Normal"], [84511, "0:10", 1, 10, "Normal"]]}}}
        row_ = rs.curiosity_rows(self.RECORDS, data, 0)[0]
        self.assertEqual((row_["said_reached"], row_["game_reached"]), (True, True))  # FAULT case of the old lookup

    def test_a_never_arrived_detour_still_reads_false(self):
        data = {"game_reads": {"tiles": {"start": [0, "0:10", 5, 5, "Normal"],
                                         "steps": [[84000, "0:10", 3, 10, "Normal"], [84530, "0:10", 0, 10, "Normal"]]}}}
        self.assertFalse(rs.curiosity_rows(self.RECORDS, data, 0)[0]["game_reached"])  # CONTROL: arrived only after
        self.assertEqual(rs.stood_during(data, 84462, 84492), {("0:10", 3, 10)})


class RegradeTests(unittest.TestCase):
    LEDGER = {"entries": [{"id": 39, "driver": "rate_step5", "purpose": "development", "status": "done", "first": 1307,
                           "last": 1318, "evidence": "e.txt"},
                          {"id": 40, "driver": "rate_step5", "purpose": "graded", "status": "done", "first": 961,
                           "last": 980}]}

    @staticmethod
    def play() -> dict:
        return {"story": {"changes": [{"mark": "VAR_BIRCH_LAB_STATE", "to": 2, "f": 50,
                                       "stats": {"trainer_battles": 0, "wild_battles": 0}},
                                      {"mark": "DEFEATED_RIVAL_ROUTE103", "to": 1, "f": 500, "party": [[0, 9, 20, 30]],
                                       "stats": {"trainer_battles": 1, "wild_battles": 3}},
                                      {"mark": "RECEIVED_POKEDEX_FROM_BIRCH", "to": 1, "f": 800,
                                       "stats": {"trainer_battles": 1, "wild_battles": 3}}], "battles": [], "frames": 1000},
                "story_truth": {"marks": {"DEFEATED_RIVAL_ROUTE103": 1, "RECEIVED_POKEDEX_FROM_BIRCH": 1}}, "frames": 1000,
                "reason": "play: done", "seconds": 2.0, "report": {"losses": 0},
                "waits_game": {"longest": [0, 0, 150], "samples": 9}, "max_losses": 3,
                "places": {"moves": [[10, "0:16", 1, 1]], "push": {"longest": [0, 0, 500, 5]}, "samples": 9, "every": 10,
                           "battles": [[200, 290]]},
                "game_reads": {"tiles": {"start": [0, "0:16", 1, 0, "Normal"], "steps": [[100, "0:16", 1, 1, "Tall Grass"]]},
                               "stop": {"by": "ai"}, "frames": {"equal": True}}}

    def kept(self, root: Path) -> list[dict]:
        actions = [{"decision": "goal", "action": "go", "frame": 0}, {"decision": "watch", "frame": 900}]
        folder = root / "ai_step5_CH1_1307_abc"
        folder.mkdir()
        (folder / rs.RUN_FILE).write_text(json.dumps({"plan": "CH1", "seed": 1307, "base": None, "personality": "Catcher",
                                                      "starter": "TREECKO", "play": self.play()}), encoding="utf-8")
        (folder / "actions.jsonl").write_text("\n".join(json.dumps(a) for a in actions), encoding="utf-8")
        return actions

    def test_a_graded_purpose_and_a_non_development_source_refuse(self):
        with tempfile.TemporaryDirectory() as root:
            self.kept(Path(root))
            for purpose in ("graded", "development", "replay"):
                with self.subTest(purpose=purpose), self.assertRaisesRegex(ValueError, "never"):
                    rs.regrade(Path(root), 39, purpose, 300000, self.LEDGER)  # FAULT: a re-grade is never graded
            for entry in (40, 41):
                with self.subTest(entry=entry), self.assertRaisesRegex(ValueError, "not a finished development"):
                    rs.regrade(Path(root), entry, rs.REGRADE, 300000, self.LEDGER)  # FAULT: graded / unknown source
            lines, _ = rs.regrade(Path(root), 39, rs.REGRADE, 300000, self.LEDGER)  # CONTROL
        self.assertTrue(lines[0].startswith("RE-GRADE (DEVELOPMENT ONLY") and "ledger #39" in lines[0])
        self.assertTrue(lines[-1].startswith("RE-GRADE VERDICT: ") and "ledger #39" in lines[-1])

    def test_an_empty_root_refuses(self):
        with tempfile.TemporaryDirectory() as root, self.assertRaisesRegex(ValueError, "no kept run folder"):
            rs.regrade(Path(root), 39, rs.REGRADE, 300000, self.LEDGER)

    def test_a_regrade_of_a_kept_folder_equals_the_original_grade(self):
        with tempfile.TemporaryDirectory() as root:
            actions = self.kept(Path(root))
            kept = rs.kept_rows(Path(root), 300000)["CH1"][0]
        direct = rs.grade_run("CH1", 1307, "Catcher", "TREECKO", self.play(), actions, 2.0)
        direct["budget"] = 300000
        # the GAME reads `grade_run` records for the re-sourced checks (each call's deletion must show here): one grass
        # step between the marks, the tiles stood on, the dex at 800 less the battle's 100 frames
        self.assertEqual((direct["grass_before_rival"], direct["grass_stint"], direct["_stood"]),
                         (1, 0, {"0:16 1,0", "0:16 1,1"}))
        self.assertEqual(direct["dex_game"], {"frame": 800, "no_battle": 700, "at_end": False})
        self.assertIsNone(direct["wally_game"])
        public = {k: v for k, v in kept.items() if not k.startswith("_")}
        want = {k: v for k, v in direct.items() if not k.startswith("_")}
        self.assertEqual({k: public[k] for k in want}, want)
        self.assertEqual(kept["_stood"], direct["_stood"])
        self.assertEqual((public["harness_stop"], public["frames_equal"]), ("ai", True))
        statuses = [(c.id, c.status, c.text) for c in grade_sweep({"CH1": [kept]})]
        self.assertEqual(statuses, [(c.id, c.status, c.text) for c in grade_sweep({"CH1": [{**direct, **{
            k: kept[k] for k in ("harness_stop", "frames_equal")}}]})])

    def test_the_cli_refuses_a_graded_regrade_and_a_register(self):
        for argv in (["--purpose", "graded", "--first-seed", "1", "--runs", "x", "--ledger-entry", "39"],
                     ["--purpose", rs.REGRADE, "--runs", "x", "--ledger-entry", "39", "--register"],
                     ["--purpose", rs.REGRADE, "--runs", "x"]):
            with self.subTest(argv=argv), mock.patch.object(sys, "argv", ["rate_step5.py", *argv]), \
                    mock.patch("sys.stderr"), self.assertRaises(SystemExit) as done:
                rs.main()
            self.assertEqual(done.exception.code, 2)

    def test_every_control_arm_fails_the_healthy_sweep_and_a_harmless_control_is_shown(self):
        arms = rs.control_arms(sweep())
        self.assertEqual({(c, k) for c, k, _, _ in arms}, {(c, k) for c, _, k in rs.CONTROL_ARMS})
        self.assertEqual([a[:3] for a in arms if a[2] == gc.PASS], [])  # every control FAILS or is VACUOUS
        rows = sweep()
        rows["STALL1"] = [row("STALL1", 1, await_game_max=100)]  # a control that does not stall
        shown = {(c, k): s for c, k, s, _ in rs.control_arms(rows)}
        self.assertEqual(shown[("R5.STALL", "STALL1")], gc.PASS)  # FAULT: the arm reports it, never hides it


if __name__ == "__main__":
    unittest.main()
