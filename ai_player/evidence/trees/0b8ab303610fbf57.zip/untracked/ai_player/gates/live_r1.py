"""R1 + R2 LIVE PROOF DRIVER (TEST SIDE, not in the lane; never the AI's code): the AI SAVES through the game's own dialog,
is KILLED, and CONTINUES its own save, graded by the harness's own reads (build spec 2026-10-29 section 5).

    py -3.12 -B live_r1.py control --seed N --out DIR [--frames F] [--build-root DIR]
    py -3.12 -B live_r1.py arm --arm NAME --seed N --out DIR [--between-from CONTROL_ROW] [--frames F] [--build-root DIR]
    py -3.12 -B live_r1.py grade ROW.json ...                     (offline: re-grade recorded rows)
    py -3.12 -B live_r1.py measure --out DIR                       (offline: step 6 (b)'s numbers over the CONTROL rows)
    `child-a` and `child-b` are the internal entries of the child processes.

WHY A PARENT AND CHILDREN (the probe's pattern, `gates/probe_save_kill.py`): a kill cannot be observed from inside the
process it kills. So:
  * CHILD A is the REAL play brain, in-process (`play_harness.run` with `--profile-dir`: a FILE-BACKED cartridge save on a
    throwaway profile under `--out/profiles/`, never under the build root's; builder note 1), from a NEW GAME on an
    EMPTY cart (asserted before it boots: no save, no `.ss1`, finding F14), the cartridge clock pinned, with `--memory`
    (always the profile's `AppPaths` path). A test-side per-frame watcher (`SaveWatch`) records each save's flash write
    from the emulator's own flash (e3: the first changed byte; the sectors complete with the new counter, each at its
    frame; e4: all 14), the RAM truth at e3 (`probe_save_kill.ram_truth`: PIDs, map, tile, play time), the AI's memory
    lines as they reach the file, every map the player stands on (RAM), every START press with the harness's own HELD
    free read before it (`probe_end_screen.game_screen`) and the big moments' proofs (`knowledge/milestones.json`, the
    harness's flag reads). At the arm's frame it prints READY and BLOCKS (no frame in flight); the parent kills ITS PID.
  * At the kill the parent FREEZES the cart and the memory (findings G6, F12) and reads the FILE verdict with the probe's
    own parser (`parse_image` + `file_verdict`, builder note 4).
  * CHILD B is the AI continuing: its own copy of the frozen set, the launcher's `memory_check` and `seed_profile`
    continue branch first, then the same brain with `--continue` for `CONTINUE_BUDGET + ARRIVAL_BUDGET + 600` frames. Its
    watcher (`ArrivalWatch`) reads, by the harness: the play time the power-on read copied into RAM, the main menu's task
    and cursor at every press, the error pages' words (printer 7), and the HELD free arrival's identity.

KILL POINTS AND EXPECTATIONS (spec section 5; ORCHESTRATOR RULING 1, 2026-10-29): no constant rests on the probe's exact
frame counts. Every expectation that depends on how far a write has got follows the NEW-SECTOR COUNT the arm's OWN
per-frame record shows AT the kill frame (`expected_file`). K-SILENT counts only if its record shows the AI's S2 memory
line written BEFORE the kill AND no new sector complete AT it (builder note 5); K-BETWEEN only with its determinism line
(builder note 2: the presses up to the kill and S1's events and truth equal the earlier CONTROL run's of the same seed).

GRADED, per arm, by the second path only (spec section 5's checks 1-7, `grade`). Development constants that step 6 sets
from its own measurements are marked PROVISIONAL below.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from ai_player.gates.probe_save_kill import (  # noqa: E402
    BLOCK_SECONDS, IDENTITY_KEYS, SECTORS_PER_SLOT, Child, brief, child_env, file_verdict, new_ids, parse_image,
)

TARGET = "ch1_pokedex"
FRAMES_A = 330000
GAME_CLOCK = "2026-10-14T10:00"
WALL_CLOCK = "10:00"
#: the HELD free read: this many more frames free, no input needed (the probe's `--after`)
AFTER = 10
#: the frames after a START press during which the watcher reads the flash every frame (a dialog's START to free was
#: 1,603 frames at the AI's slowest pacing, stage 1; 2x and more)
ACTIVE_FRAMES = 4000
#: outside a dialog, the flash is still read this often (a write with no START before it would be seen)
IDLE_FLASH_EVERY = 60
#: the big moments' proofs are sampled this often (the harness's `StoryRecorder` samples every 30)
PROOF_EVERY = 10
#: (spec section 5) the kill rules: `S<save>.<event>+<frames>` (the event's frame read from the arm's OWN record), or the
#: K-BETWEEN midpoint rule, computed from an earlier CONTROL run of the same seed
KILLS = {"K-AFTER": "S2.e4+40", "K-INSIDE": "S2.e3+130", "K-SILENT": "S2.e3+9", "K-FIRST": "S1.e3+128",
         "K-BETWEEN": "between"}
#: SET from step 6's measured wall times (spec F13: 2x the longest, never under 1200 / 300 s): child A to its kill point
#: took at most 198.8 s (K-INSIDE, 12 emulators running beside the bot tuner) and a whole CONTROL at most 316.8 s; child B
#: at most 16.4 s. Both floors apply.
CHILD_A_TIMEOUT = 1200
CHILD_B_TIMEOUT = 300
#: (builder note 3) check 6's "within the frames of one decision" after a big moment's proof turned true, SET from step 6
#: (b): on seeds 5401-5406 the 18 big-moment saves began (START) 12 to 55 frames after the harness's sampled proof turned
#: true (`measure`, s53/r1build/build/s5-dev); 2x the widest is 110 (ORCHESTRATOR RULING 1's margin)
MOMENT_FRAMES = 110
#: (D3) the big moments (= `brain/saving.py` BIG_MOMENTS; read from the AI's module ONLY to name them, never to grade)
BIG_MOMENTS = ("ch1_lab", "ch1_rival_route103", "ch1_pokedex", "ch2_wally", "ch3_woods", "ch4_roxanne")
CENTER_SUFFIX = "POKEMON_CENTER_1F"
KNOWLEDGE = REPO / "ai_player" / "knowledge" / "milestones.json"


def plan_of(seed: int) -> tuple[str, str]:
    from ai_player.gates.rate_step5 import plan_of as plan

    return plan(seed)


def now() -> str:
    return time.strftime("%Y-%m-%d %I:%M:%S %p")


# ------------------------------------------------------------------ the harness's own reads (child side)
def _sym(name: str, size: int, offset: int = 0) -> int:
    from modules.memory import read_symbol

    return int.from_bytes(bytes(read_symbol(name, offset, size)), "little")


def blocks_moving() -> bool:
    """gMain.vblankCallback NULL: the save blocks may be moving this frame (`play_harness.story_truth`'s guard)."""
    return _sym("gMain", 4, 0x0C) == 0


def map_now(emulator) -> str | None:
    """SaveBlock1's map (group:number) by RAM, None while the save blocks may move."""
    if blocks_moving():
        return None
    sb1 = _sym("gSaveBlock1Ptr", 4)
    if not sb1:
        return None  # before the game set its save blocks up (power-on)
    location = bytes(emulator.read_bytes(sb1 + 0x04, 2))
    return f"{location[0]}:{location[1]}"


def map_const(key: str | None) -> str | None:
    """The framework's name of a map (`modules.map_data.get_map_enum`), e.g. OLDALE_TOWN_POKEMON_CENTER_1F."""
    if key is None:
        return None
    from modules.map_data import get_map_enum

    group, number = (int(v) for v in key.split(":"))
    try:
        return get_map_enum((group, number)).name
    except Exception:  # noqa: BLE001 - an unknown map: named by its numbers
        return None


def proofs() -> dict[str, dict]:
    """The big moments' proofs from `knowledge/milestones.json` (decomp-checked): flag numbers, var numbers with their
    least value, trainer flag numbers."""
    data = json.loads(KNOWLEDGE.read_text(encoding="utf-8"))
    out = {}
    for milestone in data["milestones"]:
        if milestone["id"] in BIG_MOMENTS:
            done = milestone["done"]
            out[milestone["id"]] = {"flags": list(done["flags"].values()) + list(done["trainers"].values()),
                                    "vars": [[info["number"], info["at_least"]] for info in done["variables"].values()]}
    return out


def proof_now(emulator, wanted: dict[str, dict]) -> dict[str, bool] | None:
    """Which proofs hold now, by the harness's own reads of SaveBlock1's flags and vars (None while the blocks move)."""
    if blocks_moving():
        return None
    sb1 = _sym("gSaveBlock1Ptr", 4)
    if not sb1:
        return None
    flags = bytes(emulator.read_bytes(sb1 + 0x1270, 300))
    variables = bytes(emulator.read_bytes(sb1 + 0x139C, 0x200))
    out = {}
    for name, proof in wanted.items():
        ok = all((flags[n // 8] >> (n % 8)) & 1 for n in proof["flags"])
        for number, least in proof["vars"]:
            at = 2 * (number - 0x4000)
            ok = ok and int.from_bytes(variables[at:at + 2], "little") >= least
        out[name] = ok
    return out


def presses_digest(log: list[list], upto: int) -> str:
    """The sha256 of the harness's press log (frame, button, kind, frames) up to and including frame `upto`: the
    determinism line's trajectory (builder note 2)."""
    rows = [entry[:4] for entry in log if entry[0] is not None and entry[0] <= upto]
    return hashlib.sha256(json.dumps(rows).encode()).hexdigest()[:16] + f"/{len(rows)}"


def parse_kill(spec: str | None):
    if not spec or spec == "none":
        return None
    if spec.startswith("F"):
        return ("F", int(spec[1:]))
    head, _, offset = spec.partition("+")
    save, _, event = head.partition(".")
    if not save.startswith("S") or event not in ("e1", "e3", "e4", "e7"):
        raise ValueError(f"bad kill {spec!r}")
    return ("S", int(save[1:]), event, int(offset or 0))


class MemoryTail:
    """The memory file's lines as they reach it (test side: a read of the file, never the AI's objects)."""

    def __init__(self, path: Path) -> None:
        self.path, self.size, self.buffer, self.lines = path, 0, b"", []

    def poll(self, frame: int) -> list[dict]:
        try:
            size = self.path.stat().st_size
        except OSError:
            return []
        if size <= self.size:
            return []
        with open(self.path, "rb") as handle:
            handle.seek(self.size)
            self.buffer += handle.read(size - self.size)
        self.size = size
        new = []
        while b"\n" in self.buffer:
            raw, self.buffer = self.buffer.split(b"\n", 1)
            if not raw.strip():
                continue
            try:
                line = json.loads(raw)
            except ValueError:
                line = {"kind": "(unreadable)", "length": len(raw)}
            record = {k: v for k, v in line.items() if k not in ("memory", "payload")}
            record["seen_at"] = frame
            record["bytes"] = len(raw)
            new.append(record)
        self.lines += new
        return new


class SaveWatch:
    """Child A's per-frame watcher (module docstring)."""

    def __init__(self, context, controls, memory: Path, kill: str | None, record: Path) -> None:
        self.context, self.emulator, self.controls = context, context.emulator, controls
        self.kill_spec = kill
        self.kill = parse_kill(kill)
        self.record = open(record, "w", encoding="utf-8", buffering=1)
        self.flash = bytes(self.emulator.read_save_data())
        self.parse = parse_image(self.flash)
        self.baseline = self.flash
        self.baseline_counters = self._counters()
        self.idle_counter = _sym("gSaveCounter", 4)
        self.dirt = self._dirt()
        self.saves: list[dict] = []
        self.cur: dict | None = None
        self.free_since: int | None = None
        self.ring: collections.deque = collections.deque(maxlen=AFTER + 6)
        self.maps: list[list] = []
        self.starts: list[dict] = []
        self.seen_presses = 0
        self.active_until = -1
        self.memory = MemoryTail(memory)
        self.wanted = proofs()
        self.proof_first: dict[str, int] = {}
        self.proof_pending: dict[str, int] = {}
        self.flash_reads = 0
        self.last_read = -1
        self.saves_pending_line: dict | None = None
        self.frames = 0
        self.at_start = {"flash": brief(self.parse)["status"], "size": len(self.flash), "frame": self.emulator.get_frame_count()}

    def _trace(self, f: int) -> None:
        span = os.environ.get("LIVE_R1_TRACE", "")
        if not span:
            return
        first, _, last = span.partition("-")
        if not int(first) <= f <= int(last):
            return
        flash = bytes(self.emulator.read_save_data())
        before = getattr(self, "_trace_prev", None)
        self._trace_prev = flash
        if before is None:
            return
        changed = []
        for p in range(len(flash) // 0x1000):
            a, b = before[p * 0x1000:(p + 1) * 0x1000], flash[p * 0x1000:(p + 1) * 0x1000]
            if a != b:
                offsets = [i for i in range(0x1000) if a[i] != b[i]]
                changed.append([p, offsets[0], offsets[-1], len(offsets), b[0xFF4:0x1000].hex()])
        self.record.write(json.dumps({"trace": f, "dirt": self._dirt(), "changed": changed}) + "\n")

    def _counters(self) -> set:
        """The counters of every valid sector of the flash as last parsed."""
        return {s[4] for s in self._valid()}

    def _valid(self) -> list[list]:
        """Every valid sector of the flash as last parsed: [physical, id, signature, valid, counter]."""
        return [s for slot in self.parse["slots"] for s in slot["sectors"] if s[3]]

    def _changed_physical(self) -> set[int]:
        size = 0x1000
        return {p for p in range(2 * SECTORS_PER_SLOT)
                if self.flash[p * size:(p + 1) * size] != self.baseline[p * size:(p + 1) * size]}

    def _rewritten(self) -> list[int]:
        """The sector ids this write has COMPLETED: valid now, and their physical sector rewritten since the baseline."""
        changed = self._changed_physical()
        return sorted({s[1] for s in self._valid() if s[0] in changed})

    def _dirt(self) -> list[int]:
        data = self.emulator._core._native.memory.savedata  # noqa: SLF001 - test side: mGBA's own save bookkeeping
        return [int(data.dirty), int(data.dirtAge)]

    def after_frame(self) -> None:
        from ai_player.gates.play_harness import party_now
        from ai_player.gates.probe_end_screen import game_screen
        from ai_player.gates.probe_save_kill import ram_truth

        emulator = self.emulator
        f = emulator.get_frame_count()
        self.frames += 1
        try:
            screen = game_screen()
            free, overworld = bool(screen["free"]), bool(screen["overworld"])
        except Exception:  # noqa: BLE001
            free, overworld = False, False
        self.ring.append((f, free))
        # the presses since the last frame: a START begins a dialog (its look was the frame the press logs)
        log = self.controls.log
        while self.seen_presses < len(log):
            entry = log[self.seen_presses]
            self.seen_presses += 1
            if entry[1] == "Start":
                pressed = entry[0]
                before = [ok for frame, ok in self.ring if frame is not None and pressed is not None
                          and pressed - AFTER <= frame <= pressed]
                key = map_now(emulator)
                try:
                    party = party_now()
                except Exception:  # noqa: BLE001
                    party = None
                self.starts.append({"f": pressed, "held_free": len(before) == AFTER + 1 and all(before),
                                    "free_frames": len(before), "overworld": overworld, "map": key,
                                    "const": map_const(key), "party": party, "presses_before": self.seen_presses - 1})
                self.active_until = (pressed or f) + ACTIVE_FRAMES
        # the map the player stands on (RAM)
        key = map_now(emulator)
        if key is not None and (not self.maps or self.maps[-1][1] != key):
            self.maps.append([f, key])
        # the big moments' proofs (confirmed by a second sample)
        if self.frames % PROOF_EVERY == 0:
            held = proof_now(emulator, {k: v for k, v in self.wanted.items() if k not in self.proof_first})
            for name, ok in (held or {}).items():
                if ok and name in self.proof_pending:
                    self.proof_first[name] = self.proof_pending.pop(name)
                elif ok:
                    self.proof_pending[name] = f
                else:
                    self.proof_pending.pop(name, None)
        # the memory file's lines, the frame each was first seen
        for line in self.memory.poll(f):
            if line.get("kind") == "save" and self.cur is not None and "line" not in self.cur:
                self.cur["line"] = line
            elif line.get("kind") == "save":
                self.saves_pending_line = line
        # (development) LIVE_R1_TRACE="first-last": every frame in that range, which bytes of which sector changed
        self._trace(f)
        # the flash: every frame inside a dialog or a write, on mGBA's own write mark, else every IDLE_FLASH_EVERY
        dirt = self._dirt()
        if self.cur is not None or f <= self.active_until or dirt != self.dirt or f % IDLE_FLASH_EVERY == 0:
            self._flash(f, ram_truth)
        self.dirt = dirt
        if self.cur is not None and "e4" in self.cur and "e7" not in self.cur:
            if free:
                self.free_since = f if self.free_since is None else self.free_since
                if f - self.free_since >= AFTER:
                    self.cur["e7"] = self.free_since
                    # the baseline for the next write: the flash NOW (a change between e4 and here is recorded, never
                    # taken for a new save)
                    flash = bytes(emulator.read_save_data())
                    self.cur["flash_changed_after_e4"] = flash != self.baseline
                    self.baseline = self.flash = flash
                    self.parse = parse_image(flash)
                    self.baseline_counters = self._counters()
                    self.cur = None
            else:
                self.free_since = None
        elif self.cur is None:
            self.idle_counter = _sym("gSaveCounter", 4)
        self._check_kill(f)

    def _flash(self, f: int, ram_truth) -> None:
        self.flash_reads += 1
        previous, self.last_read = self.last_read, f
        flash = bytes(self.emulator.read_save_data())
        if flash != self.flash:
            self.flash = flash
            self.parse = parse_image(flash)
        if self.cur is None and flash != self.baseline:
            index = len(self.saves) + 1
            start = next((s for s in reversed(self.starts) if s["f"] is not None and s["f"] <= f), None)
            # e3 is EXACT only when the frame before was read too (the flash then still equalled the baseline)
            exact = previous == f - 1
            self.cur = {"save": index, "counter": self.idle_counter + 1, "e3": f, "e3_exact": exact,
                        "e1": start["f"] if start else None, "start": start, "truth": ram_truth(self.emulator),
                        "sectors": {}, "new_now": 0}
            pending = self.saves_pending_line
            if pending is not None and (start is None or pending.get("frame", -1) >= (start["f"] or 0)):
                self.cur["line"] = pending
            self.saves_pending_line = None
            self.saves.append(self.cur)
        cur = self.cur
        if cur is not None and "e4" not in cur:
            # THE NEW SECTORS: valid sectors (signature and checksum, the game's own test, `parse_slot`) whose 4 KiB differ
            # from the flash before this write. Counter-free, because a counter cannot be predicted here: the first
            # development run guessed `gSaveCounter + 1` read before the write (the probe's rule on a loaded state) and on
            # a NEW GAME it named no sector at all (0 new sectors through a whole write); the second took the newest
            # counter no earlier sector carried and on seed 5403 latched 0xFFFF0002, a sector whose counter word was
            # still being programmed (flash bits only go 1 -> 0, so a half-written counter reads HIGH), and missed e4.
            ids = self._rewritten()
            counters = sorted({s[4] for s in self._valid() if s[1] in ids and s[0] in self._changed_physical()})
            if counters:
                cur["counter"] = counters[0]
                cur["counters_seen"] = sorted(set(cur.get("counters_seen", [])) | set(counters))
            for sid in ids:
                cur["sectors"].setdefault(str(sid), f)
            cur["new_now"] = len(ids)
            # e4: all 14 rewritten AND one counter among them. A sector's counter word is programmed over two frames, and
            # half-programmed it still reads valid (MEASURED, seed 5405 save 4: the last sector's counter read 0xFFFF0004
            # at f142078 and 4 at f142079); e4 taken at the half-written frame left a stale baseline, and the counter's
            # last two bytes then read as a NEW save 197 frames later
            if len(ids) == SECTORS_PER_SLOT and len(counters) == 1:
                cur["e4"] = f
                loaded = self.parse.get("loaded") or {}
                cur["slot_at_e4_equals_truth"] = all(loaded.get(k) == cur["truth"].get(k) for k in IDENTITY_KEYS)
                cur["slot_at_e4"] = {k: loaded.get(k) for k in IDENTITY_KEYS}
                self.baseline = self.flash
                self.baseline_counters = self._counters()
            self.record.write(json.dumps({"f": f, "save": cur["save"], "new": len(ids),
                                          "status": self.parse["status"]}) + "\n")

    def _check_kill(self, f: int) -> None:
        kill = self.kill
        if kill is None:
            return
        if kill[0] == "F":
            reached = f >= kill[1]
        else:
            _, index, event, offset = kill
            save = self.saves[index - 1] if len(self.saves) >= index else None
            reached = save is not None and event in save and save[event] is not None and f - save[event] >= offset
        if not reached:
            return
        payload = self.result()
        cur = self.saves[kill[1] - 1] if kill[0] == "S" else None
        payload["kill"] = {"spec": self.kill_spec, "frame": f,
                           "new_sectors_at_kill": None if cur is None or "e4" in cur else cur["new_now"],
                           "write_complete_at_kill": None if cur is None else "e4" in cur,
                           "presses_digest": presses_digest(self.controls.log, f),
                           "status_at_kill": self.parse["status"]}
        self.record.flush()
        print("READY " + json.dumps(payload, ensure_ascii=False), flush=True)
        for _ in range(int(BLOCK_SECONDS / 0.25)):
            time.sleep(0.25)
        print("NOT KILLED: the parent never killed this child; it ends itself (exit 5)", flush=True)
        os._exit(5)

    def result(self) -> dict:
        saves = []
        for save in self.saves:
            item = {k: v for k, v in save.items() if k != "start"}
            item["start"] = save.get("start")
            if save.get("sectors"):
                item["first_sector"] = min(save["sectors"].values())
            saves.append(item)
        return {"saves": saves, "truths": {f"S{s['save']}": s["truth"] for s in self.saves},
                "maps": self.maps, "starts": self.starts, "proof_first": self.proof_first,
                "memory_lines": self.memory.lines, "flash_reads": self.flash_reads, "frames": self.frames,
                "at_start": self.at_start}


class ArrivalWatch:
    """Child B's per-frame watcher (module docstring): the boot read, the main menu at every press, the pages' words,
    the held free arrival."""

    def __init__(self, context, controls) -> None:
        self.context, self.emulator, self.controls = context, context.emulator, controls
        self.menu: tuple | None = None
        self.menu_input_from: int | None = None
        self.boot: dict | None = None
        self.pages: list[dict] = []
        self.page_keys: set = set()
        self.presses: list[list] = []
        self.seen_presses = 0
        self.overworld_from: int | None = None
        self.free_since: int | None = None
        self.candidate: dict | None = None
        self.arrival: dict | None = None
        self.first_look: dict | None = None
        self.frames = 0
        self.new_game_tasks: list[list] = []

    def after_frame(self) -> None:
        from ai_player.gates.probe_end_screen import game_screen
        from ai_player.gates.probe_save_kill import (
            ERROR_TASKS, main_menu_task, printer_page, ram_truth, second_path_truth,
        )
        from modules.memory import read_symbol
        from modules.tasks import TaskList

        emulator = self.emulator
        f = emulator.get_frame_count()
        self.frames += 1
        if self.first_look is None:
            screen = game_screen()
            self.first_look = {"f": f, "overworld": screen["overworld"], "callback2": screen["callback2"]}
        # presses since the last frame, with the main menu as the harness read it on the look before
        log = self.controls.log
        while self.seen_presses < len(log):
            entry = log[self.seen_presses]
            self.seen_presses += 1
            self.presses.append([entry[0], entry[1], self.menu])
        if self.arrival is None:
            name, data0, data1 = main_menu_task()
            self.menu = (name, data0, data1, f)
            if name == "Task_HandleMainMenuInput" and self.menu_input_from is None:
                self.menu_input_from = f
                self.boot = ram_truth(emulator)  # what the power-on read copied into RAM (`LoadGameSave`)
                self.boot["menu_type"], self.boot["cursor"] = data0, data1
            if name in ERROR_TASKS:
                page = printer_page(7)
                key = (name, page.get("symbol"))
                if not page["active"] and key not in self.page_keys:
                    self.page_keys.add(key)
                    self.pages.append({"task": name, "symbol": page.get("symbol"), "text": page.get("text"), "f": f})
            tasks = TaskList(read_symbol("gTasks"))
            births = [t for t in ("Task_NewGameBirchSpeech_Init", "Task_NewGameBirchSpeechSub_InitPokeBall")
                      if tasks[t] is not None]
            if births:
                self.new_game_tasks.append([f, births])
            screen = game_screen()
            if screen["overworld"] and self.menu_input_from is not None:
                self.overworld_from = self.overworld_from or f
                if screen["free"]:
                    if self.free_since is None:
                        self.free_since = f
                        self.candidate = {"f": f, **ram_truth(emulator), "second_path": second_path_truth(self.context)}
                    elif f - self.free_since >= AFTER:
                        self.arrival = self.candidate
                else:
                    self.free_since, self.candidate = None, None

    def result(self) -> dict:
        return {"boot": self.boot, "menu_input_from": self.menu_input_from, "pages": self.pages, "presses": self.presses,
                "overworld_from": self.overworld_from, "arrival": self.arrival, "first_look": self.first_look,
                "frames": self.frames, "new_game_tasks": self.new_game_tasks}


# ------------------------------------------------------------------ the children
def child_a(args) -> int:
    from ai_player.gates import play_harness

    profile = Path(args.profile_dir)
    personality, starter = plan_of(args.seed)
    watchers: list = []

    def watch(controls):
        from modules.context import context

        watcher = SaveWatch(context, controls, Path(args.memory), args.kill, Path(args.record))
        watchers.append(watcher)
        return [watcher]

    result = play_harness.run(None, args.seed, args.frames, personality, starter, TARGET, set(), GAME_CLOCK, WALL_CLOCK,
                              None, Path(args.run_dir), None, 30, profile_dir=profile, memory=Path(args.memory),
                              watch=watch)
    Path(args.play_json).write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    out = watchers[0].result() if watchers else {}
    out["play"] = {k: result.get(k) for k in ("reason", "frames", "seconds", "presses", "personality", "starter")}
    out["play"]["saves"] = (result.get("report") or {}).get("saves")
    out["play"]["end_save"] = (result.get("report") or {}).get("end_save")
    out["play"]["lines_save"] = [line for line in result.get("lines") or [] if "[AI-SAVE]" in line]
    print("RESULT " + json.dumps(out, ensure_ascii=False), flush=True)
    return 0


def child_b(args) -> int:
    from ai_player.gates import play_harness
    from ai_player.host.launcher import memory_check, seed_profile
    from ai_player.paths import AppPaths
    from ai_player.skills.saving import ARRIVAL_BUDGET, CONTINUE_BUDGET

    profile = Path(args.profile_dir)
    game = AppPaths.for_profile(profile.name, profile.parent.parent, home="")
    check = memory_check(game)
    out = {"memory_check": {"ok": check.ok, "why": check.why, "end_class": check.end_class, "undone": check.undone,
                            "newest": (check.newest or {}).get("id")}}
    if not check.ok:
        out["refused"] = check.why
        print("RESULT " + json.dumps(out, ensure_ascii=False), flush=True)
        return 0
    out["seed_profile"] = seed_profile(profile, None, False, continue_game=True, game=game)
    out["ss1_at_boot"] = (profile / "current_state.ss1").exists()
    personality, starter = plan_of(args.seed)
    watchers: list = []

    def watch(controls):
        from modules.context import context

        watcher = ArrivalWatch(context, controls)
        watchers.append(watcher)
        return [watcher]

    frames = args.frames or CONTINUE_BUDGET + ARRIVAL_BUDGET + 600
    result = play_harness.run(None, args.seed, frames, personality, starter, TARGET, set(), GAME_CLOCK, WALL_CLOCK,
                              None, Path(args.run_dir), None, 30, profile_dir=profile, memory=game.memory_jsonl,
                              continue_game=True, watch=watch)
    Path(args.play_json).write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    out.update(watchers[0].result() if watchers else {})
    out["frames_budget"] = frames
    out["play"] = {k: result.get(k) for k in ("reason", "frames", "seconds", "presses")}
    out["play"]["lines_save"] = [line for line in result.get("lines") or [] if "[AI-SAVE]" in line or "continue:" in line]
    print("RESULT " + json.dumps(out, ensure_ascii=False), flush=True)
    return 0


# ------------------------------------------------------------------ the parent
def make_profile(out: Path, name: str, donor: Path) -> Path:
    from ai_player.host.launcher import PROFILE_MARKER

    profile = out / "profiles" / name
    if profile.exists():
        raise SystemExit(f"{profile} exists: a fresh --out (or arm) is needed (nothing is reused)")
    profile.mkdir(parents=True)
    shutil.copy2(donor, profile / "metadata.yml")
    (profile / PROFILE_MARKER).write_text("live_r1 throwaway profile\n", encoding="utf-8")
    return profile


def fresh_cart(profile: Path) -> dict:
    """(finding F14) The cart child A boots: an EMPTY `current_save.sav`, no `.ss1` (else the arm is refused)."""
    save = profile / "current_save.sav"
    save.write_bytes(b"")
    states = list(profile.glob("*.ss1")) + list((profile / "states").glob("*.ss1"))
    ok = save.stat().st_size == 0 and not states
    return {"ok": ok, "sav_bytes": save.stat().st_size, "ss1": [str(p) for p in states]}


def ctx_of(args) -> dict:
    from ai_player.gates.hands_harness import PROFILE
    from ai_player.host.launcher import ENV_BUILD_ROOT, resolve_build_root

    build_root = Path(args.build_root or os.environ.get(ENV_BUILD_ROOT) or resolve_build_root()).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    return {"out": out, "build_root": build_root, "donor": build_root / "profiles" / PROFILE / "metadata.yml",
            "env": child_env(build_root), "script": Path(__file__).resolve()}


def run_child_a(ctx: dict, tag: str, seed: int, kill: str, frames: int) -> tuple[dict, Path]:
    out = ctx["out"]
    from ai_player.paths import AppPaths

    name = f"ai-r1live-{tag.lower()}-{seed}"
    profile = make_profile(out, name, ctx["donor"])
    cart = fresh_cart(profile)
    folder = out / "runs" / f"{tag}-{seed}"
    folder.mkdir(parents=True)
    row: dict = {"arm": tag, "seed": seed, "kill": kill, "profile": str(profile), "folder": str(folder), "fresh_cart": cart,
                 "started": now()}
    if not cart["ok"]:
        row["refused"] = f"the cart is not fresh: {cart}"
        return row, profile
    game = AppPaths.for_profile(name, out, home="")
    cmd = [sys.executable, "-B", str(ctx["script"]), "child-a", "--profile-dir", str(profile), "--memory",
           str(game.memory_jsonl), "--seed", str(seed), "--frames", str(frames), "--kill", kill, "--record",
           str(folder / "a_flash.jsonl"), "--run-dir", str(folder / "a_run"), "--play-json", str(folder / "a_play.json")]
    began = time.monotonic()
    a = Child(cmd, ctx["env"], REPO, folder / "child_a.out", tag, "child A")
    word, result = a.wait_for(("READY", "RESULT", "ABORT"), CHILD_A_TIMEOUT)
    row["child_a"] = {"pid": a.pid, "word": word, "seconds": round(time.monotonic() - began, 1)}
    if word == "READY":
        row["child_a"]["kill"] = a.kill()
        row["child_a"]["exit"] = row["child_a"]["kill"]["exit_code"]
    else:
        row["child_a"]["exit"] = a.finish(120)
    row["child_a"]["alive_after"] = a.proc.poll() is None
    row["a"] = result
    return row, profile


def freeze(ctx: dict, row: dict, profile: Path) -> Path:
    """(G6, F12) The cart and the memory as the kill left them, before any child B."""
    from ai_player.paths import AppPaths

    frozen = ctx["out"] / "frozen" / f"{row.get('name', row['arm'])}-{row['seed']}"
    frozen.mkdir(parents=True)
    game = AppPaths.for_profile(profile.name, ctx["out"], home="")
    copied = {}
    for source in (profile / "current_save.sav", game.memory_jsonl, game.launches_jsonl):
        if source.exists():
            shutil.copy2(source, frozen / source.name)
            copied[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()[:16]
    row["frozen"] = {"dir": str(frozen), "files": copied,
                     "ss1_after_a": sorted(p.name for p in profile.glob("*.ss1"))}
    return frozen


def run_child_b(ctx: dict, row: dict, frozen: Path, suffix: str = "b") -> None:
    from ai_player.paths import AppPaths

    name = f"ai-r1live-{row.get('name', row['arm']).lower()}-{suffix}-{row['seed']}"
    profile = make_profile(ctx["out"], name, ctx["donor"])
    game = AppPaths.for_profile(name, ctx["out"], home="")
    game.game_dir.mkdir(parents=True)
    for item in frozen.iterdir():
        target = profile / item.name if item.name.endswith(".sav") else game.game_dir / item.name
        shutil.copy2(item, target)
    folder = ctx["out"] / "runs" / f"{row.get('name', row['arm'])}-{row['seed']}"
    cmd = [sys.executable, "-B", str(ctx["script"]), "child-b", "--profile-dir", str(profile), "--seed", str(row["seed"]),
           "--run-dir", str(folder / f"{suffix}_run"), "--play-json", str(folder / f"{suffix}_play.json")]
    began = time.monotonic()
    b = Child(cmd, ctx["env"], REPO, folder / f"child_{suffix}.out", row["arm"], "child B")
    word, result = b.wait_for(("RESULT", "ABORT"), CHILD_B_TIMEOUT)
    row["child_b"] = {"pid": b.pid, "word": word, "exit": b.finish(120), "seconds": round(time.monotonic() - began, 1)}
    row["child_b"]["alive_after"] = b.proc.poll() is None
    row["b"] = result
    memory = [json.loads(line) for line in game.memory_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()] \
        if game.memory_jsonl.exists() else []
    row["b_memory"] = [{k: v for k, v in line.items() if k != "memory"} for line in memory]
    row["b_run"] = str(folder / f"{suffix}_run")


def expected_file(arm: str, a: dict) -> tuple[str | None, str]:
    """(ORCHESTRATOR RULING 1) The FILE the kill must leave, from the arm's OWN record at the kill frame."""
    kill = a.get("kill") or {}
    new = kill.get("new_sectors_at_kill")
    if arm == "K-FIRST":
        return ("CORRUPT" if new else "EMPTY"), f"{new} new sector(s) of save 1 complete at the kill"
    if arm in ("K-INSIDE", "K-SILENT"):
        return ("S1+ERROR" if new else "S1"), f"{new} new sector(s) of save 2 complete at the kill"
    if arm == "K-BETWEEN":
        return "S1", "no write under way at the kill"
    if arm == "K-AFTER":
        return "S2", "save 2's write complete at the kill"
    return None, "no kill"


def restore_snapshot(run_dir: Path) -> tuple[dict | None, str | None]:
    """(check 3, finding F2) The world memory the continued brain ACTS on: the `world.jsonl` snapshot written at the
    restore ("restored from save <id>"), found by its place among the run's world snapshots in the action log."""
    actions = run_dir / "actions.jsonl"
    world = run_dir / "world.jsonl"
    if not actions.exists() or not world.exists():
        return None, None
    index, reason = -1, None
    for line in actions.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        if record.get("decision") == "world" and record.get("action") == "snapshot":
            index += 1
            if str(record.get("reason", "")).startswith("restored from save"):
                reason = record["reason"]
                break
    else:
        return None, None
    lines = world.read_text(encoding="utf-8").splitlines()
    return (json.loads(lines[index]) if index < len(lines) else None), reason


def b_actions(run_dir: Path) -> list[dict]:
    path = run_dir / "actions.jsonl"
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()] if path.exists() else []


def new_maps(a: dict) -> list[str]:
    """`NEW`: the maps child A first stood on (its RAM record) after S1.e3 and before S2.e3. In K-BETWEEN, whose child A
    is killed BEFORE S2 begins, the end of the window is the kill frame: what it stood on after its save and before the
    kill is exactly what a memory restored as of S1 must not hold (spec: "memory has nothing newer")."""
    saves = a.get("saves") or []
    kill = (a.get("kill") or {}).get("frame")
    if not saves or (len(saves) < 2 and kill is None):
        return []
    e3_1 = saves[0]["e3"]
    e3_2 = saves[1]["e3"] if len(saves) > 1 else kill
    first: dict[str, int] = {}
    for frame, key in a.get("maps") or []:
        first.setdefault(key, frame)
    return sorted(key for key, frame in first.items() if e3_1 <= frame < e3_2)


def grade(row: dict) -> dict:
    """Spec section 5's checks 1-7 for one arm's row, by the second path only. Each check: True / False / None (not
    applicable), with its evidence."""
    arm, a, b = row["arm"], row.get("a") or {}, row.get("b") or {}
    checks: dict = {}
    notes: dict = {}
    truths = a.get("truths") or {}
    saves = a.get("saves") or []
    kill = a.get("kill") or {}
    expected, why = expected_file(arm, a)
    verdict = row.get("file", {}).get("verdict")
    checks["1_file"] = verdict == expected if expected else None
    notes["1_file"] = {"verdict": verdict, "expected": expected, "because": why}
    target = {"K-INSIDE": "S1", "K-SILENT": "S1", "K-BETWEEN": "S1", "K-AFTER": "S2"}.get(arm)
    arrival = (b.get("arrival") or {})
    if target and target in truths:
        truth = truths[target]
        same = {k: arrival.get(k) == truth.get(k) for k in ("pids", "map", "pos")}
        boot = (b.get("boot") or {}).get("play_time")
        same["play_time_at_boot"] = boot == truth.get("play_time")
        checks["2_identity"] = all(same.values())
        notes["2_identity"] = {"target": target, "same": same, "arrival": {k: arrival.get(k) for k in ("pids", "map", "pos")},
                               "truth": {k: truth.get(k) for k in IDENTITY_KEYS}, "boot_play_time": boot}
    else:
        checks["2_identity"] = None
    new = new_maps(a)
    notes["NEW"] = new
    snapshot, reason = restore_snapshot(Path(row["b_run"])) if row.get("b_run") else (None, None)
    session = next((line for line in reversed(row.get("b_memory") or []) if line.get("kind") == "session"), None)
    restored = sorted((snapshot or {}).get("maps", {}).keys()) if snapshot else None
    if arm in ("K-INSIDE", "K-SILENT", "K-BETWEEN", "K-AFTER"):
        agree = session is not None and restored is not None and sorted(session.get("restored_maps") or []) == restored
        if arm == "K-AFTER":
            ok = bool(new) and restored is not None and all(m in restored for m in new)
        else:
            ok = bool(new) and restored is not None and not any(m in restored for m in new)
        checks["3_memory"] = ok and agree
        notes["3_memory"] = {"restore_reason": reason, "restored_maps": restored, "session_restored_maps":
                             (session or {}).get("restored_maps"), "agree": agree, "continued_from":
                             (session or {}).get("continued_from"),
                             "s_line_ids": {f"S{s['save']}": (s.get("line") or {}).get("id") for s in saves}}
        want_id = (saves[0].get("line") or {}).get("id") if target == "S1" and saves else \
            (saves[1].get("line") or {}).get("id") if target == "S2" and len(saves) > 1 else None
        checks["3_restored_save"] = session is not None and session.get("continued_from") == want_id
    else:
        checks["3_memory"] = None
    # 4: the action log: CONTINUE pressed with its gate; no NEW GAME; the page read; K-FIRST: no press on the main menu
    presses = b.get("presses") or []
    on_menu = [p for p in presses if p[2] and p[2][0] == "Task_HandleMainMenuInput"]
    new_game = [p for p in on_menu if p[1] == "A" and (p[2][2] != 0 or (p[2][1] or 0) < 1)] + \
        [["task", t] for t in b.get("new_game_tasks") or []]
    actions = b_actions(Path(row["b_run"])) if row.get("b_run") else []
    # the page's words must be in a `read` note (`hands.note("read", "text", words)`), not merely told
    reads = [r for r in actions if r.get("decision") == "read"]
    words = " ".join(str(r.get("reason", "")) for r in reads).lower()
    told = " ".join(str(r.get("reason", "")) for r in actions).lower()
    four = {"no_new_game": not new_game}
    if arm == "K-FIRST":
        four["no_press_on_menu"] = not on_menu and all((p[0] or 0) < (b.get("menu_input_from") or 10 ** 9) for p in presses)
        four["page_read"] = "erased" in words
        four["stopped"] = "save is gone" in str((b.get("play") or {}).get("reason", "")) or "save is gone" in told
    else:
        four["continue_pressed"] = any(p[1] == "A" and p[2][2] == 0 and (p[2][1] or 0) >= 1 for p in on_menu)
        if arm == "K-INSIDE":
            four["page_read"] = "corrupted" in words
        if arm in ("K-SILENT", "K-BETWEEN", "K-AFTER"):
            four["no_page"] = not b.get("pages")
    checks["4_actions"] = all(four.values())
    notes["4_actions"] = {**four, "menu_presses": on_menu[:6], "pages": b.get("pages"), "read_records": len(reads)}
    # 5: each of child A's saves began on a held free screen, no battle; consecutive stamps >= 3 game minutes apart
    starts = [s.get("start") or {} for s in saves]
    stamps = [(s.get("line") or {}).get("play_time") for s in saves]
    gaps = [(b2[0] * 60 + b2[1]) - (a2[0] * 60 + a2[1]) for a2, b2 in zip(stamps, stamps[1:]) if a2 and b2]
    checks["5_free_and_gap"] = bool(saves) and all(s.get("held_free") and s.get("overworld") for s in starts) and \
        all(g >= 3 for g in gaps)
    notes["5_free_and_gap"] = {"held_free": [s.get("held_free") for s in starts], "stamps": stamps, "gaps": gaps}
    # 6: each save at a ruling-51 moment (by the harness's reads)
    moments = [moment_of(s, a.get("proof_first") or {}) for s in saves]
    checks["6_moments"] = bool(saves) and all(m["moment"] is not None for m in moments)
    notes["6_moments"] = moments
    # 7: (K-INSIDE, K-SILENT) S2's save line in the memory file with a frame below the kill frame
    if arm in ("K-INSIDE", "K-SILENT"):
        line = (saves[1].get("line") if len(saves) > 1 else None) or {}
        frozen_ids = row.get("frozen_save_lines") or []
        checks["7_s2_line_first"] = bool(line) and line.get("frame", 10 ** 9) < (kill.get("frame") or -1) and \
            line.get("id") in frozen_ids
        notes["7_s2_line_first"] = {"line_frame": line.get("frame"), "line_seen_at": line.get("seen_at"),
                                    "kill_frame": kill.get("frame"), "frozen_save_line_ids": frozen_ids,
                                    "e3": saves[1]["e3"] if len(saves) > 1 else None}
    else:
        checks["7_s2_line_first"] = None
    reach = checks["1_file"] is True and (checks["7_s2_line_first"] is not False)
    if arm == "K-SILENT":
        reach = reach and kill.get("new_sectors_at_kill") == 0
    if arm in ("K-INSIDE", "K-SILENT", "K-BETWEEN", "K-AFTER"):
        reach = reach and bool(new)
    if arm == "K-BETWEEN":
        reach = reach and bool((row.get("determinism") or {}).get("same"))
    counted = bool(reach)
    graded = {k: v for k, v in checks.items() if v is not None and k not in ("1_file", "7_s2_line_first")}
    return {"checks": checks, "notes": notes, "counted": counted,
            "pass": counted and all(graded.values()) if counted else None}


def moment_of(save: dict, proof_first: dict) -> dict:
    """(check 6) The ruling-51 moment a save began at, by the harness's reads: a POKéMON CENTER's ground floor with the
    party at full HP; or after a big moment's proof turned true (the frames since, against MOMENT_FRAMES)."""
    start = save.get("start") or {}
    e1 = save.get("e1")
    const = start.get("const") or ""
    party = start.get("party") or []
    full = bool(party) and all(m and m[2] == m[3] for m in party)
    if const.endswith(CENTER_SUFFIX) and full:
        return {"moment": "center", "const": const}
    before = sorted(((frame, name) for name, frame in proof_first.items() if e1 is not None and frame <= e1), reverse=True)
    if before:
        frame, name = before[0]
        gap = e1 - frame
        within = MOMENT_FRAMES is None or gap <= MOMENT_FRAMES
        return {"moment": f"after {name}" if within else None, "since_proof": gap, "const": const, "full_hp": full}
    if const.endswith("GYM"):
        return {"moment": "gym (leader: unit-tested only)", "const": const}
    return {"moment": None, "const": const, "full_hp": full}


def file_of(ctx: dict, row: dict, frozen: Path) -> None:
    data = (frozen / "current_save.sav").read_bytes() if (frozen / "current_save.sav").exists() else None
    parse = parse_image(data) if data is not None else None
    truths = (row.get("a") or {}).get("truths") or {}
    row["file"] = {"verdict": file_verdict(parse, truths), "parse": brief(parse)}
    memory = frozen / "memory.jsonl"
    lines = [json.loads(x) for x in memory.read_text(encoding="utf-8").splitlines() if x.strip()] if memory.exists() else []
    row["frozen_save_lines"] = [line["id"] for line in lines if line.get("kind") == "save"]


def cmd_control(args) -> int:
    ctx = ctx_of(args)
    row, _profile = run_child_a(ctx, "CONTROL", args.seed, "none", args.frames)
    row["ended"] = now()
    out = ctx["out"] / "rows" / f"CONTROL-{args.seed}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(row, ensure_ascii=False), encoding="utf-8")
    a = row.get("a") or {}
    print("LIVE CONTROL " + json.dumps({"seed": args.seed, "word": row["child_a"]["word"],
                                        "reason": (a.get("play") or {}).get("reason"),
                                        "saves": [[s["save"], s.get("e1"), s["e3"], s.get("e4"), s.get("e7"),
                                                   (s.get("line") or {}).get("id")] for s in a.get("saves") or []],
                                        "NEW": new_maps(a), "seconds": row["child_a"]["seconds"], "row": str(out)}),
          flush=True)
    return 0 if row["child_a"]["word"] == "RESULT" else 1


def cmd_arm(args) -> int:
    ctx = ctx_of(args)
    arm = args.arm
    determinism = None
    if arm == "K-BETWEEN":
        earlier = json.loads(Path(args.between_from).read_text(encoding="utf-8"))
        saves = earlier["a"]["saves"]
        if earlier["seed"] != args.seed or len(saves) < 2:
            raise SystemExit("K-BETWEEN needs a CONTROL row of the SAME seed with two saves")
        frame = (saves[0]["e7"] + saves[1]["e1"]) // 2
        if args.between_rule == "new":
            # (step 6 (c) finding, development) the spec's midpoint fell, on both rehearsal seeds, before child A stood on
            # any map it had not stood on before S1: NEW was EMPTY at the kill and check 3 could not fail. This rule kills
            # halfway between the first frame child A stands on a map of the CONTROL's NEW and S2's START
            first: dict[str, int] = {}
            for at, key in earlier["a"]["maps"]:
                first.setdefault(key, at)
            entered = min(first[key] for key in new_maps(earlier["a"]))
            frame = (entered + saves[1]["e1"]) // 2
        kill = f"F{frame}"
        determinism = {"from": args.between_from, "frame": frame, "S1": {k: saves[0].get(k) for k in ("e1", "e3", "e4", "e7")},
                       "S1_truth": saves[0]["truth"]}
        play = json.loads((Path(earlier["folder"]) / "a_play.json").read_text(encoding="utf-8"))
        determinism["presses_digest"] = presses_digest(play["game_reads"]["presses"]["log"], frame)
    else:
        kill = KILLS[arm]
    name = args.tag or arm
    row, profile = run_child_a(ctx, name, args.seed, kill, args.frames)
    row["arm"], row["name"] = arm, name
    if determinism is not None:
        determinism["rule"] = args.between_rule
    if row["child_a"]["word"] != "READY":
        row["result"] = f"NOT RUN: child A ended {row['child_a']['word']}, not at its kill"
    else:
        frozen = freeze(ctx, row, profile)
        file_of(ctx, row, frozen)
        if determinism is not None:
            a = row["a"]
            mine = {"S1": {k: a["saves"][0].get(k) for k in ("e1", "e3", "e4", "e7")}, "S1_truth": a["saves"][0]["truth"],
                    "presses_digest": a["kill"]["presses_digest"]}
            determinism["this"] = mine
            determinism["same"] = (mine["S1"] == determinism["S1"] and mine["S1_truth"] == determinism["S1_truth"]
                                   and mine["presses_digest"] == determinism["presses_digest"])
            row["determinism"] = determinism
        run_child_b(ctx, row, frozen)
        row["grade"] = grade(row)
    row["ended"] = now()
    out = ctx["out"] / "rows" / f"{name}-{args.seed}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(row, ensure_ascii=False), encoding="utf-8")
    g = row.get("grade") or {}
    print("LIVE ARM " + json.dumps({"arm": arm, "seed": args.seed, "kill": kill, "file": (row.get("file") or {}).get("verdict"),
                                    "counted": g.get("counted"), "pass": g.get("pass"), "checks": g.get("checks"),
                                    "b_reason": ((row.get("b") or {}).get("play") or {}).get("reason"),
                                    "row": str(out)}, ensure_ascii=False), flush=True)
    return 0


#: the GBA's frame rate (59.7275 frames a second): game hours from frames
FPS = 59.7275


def measure_row(row: dict) -> dict:
    """Step 6 (b)'s numbers for one CONTROL row (spec section 8 step 6 (b)): the saves, their moments (check 6), the
    dialog's frames with the AI's pacing, the line sizes, the saves per game hour (T2), T1 (the stamp's look against the
    clock's freeze at e3 - 1, and the stamp against the RAM truth's hours and minutes), NEW and the S1/S2 identities."""
    a = row.get("a") or {}
    play = a.get("play") or {}
    saves = a.get("saves") or []
    proof_first = a.get("proof_first") or {}
    pokedex = proof_first.get(TARGET)
    out_saves = []
    for save in saves:
        line = save.get("line") or {}
        truth = save.get("truth") or {}
        stamp = line.get("play_time")
        moment = moment_of(save, proof_first)
        out_saves.append({
            "save": save["save"], "id": line.get("id"), "why": line.get("why"), "e1": save.get("e1"), "e3": save["e3"],
            "e3_exact": save.get("e3_exact"), "e4": save.get("e4"), "e7": save.get("e7"),
            "start_to_e3": save["e3"] - save["e1"] if save.get("e1") is not None else None,
            "write_e4_minus_e3": save["e4"] - save["e3"] if save.get("e4") else None,
            "first_sector_minus_e3": save["first_sector"] - save["e3"] if save.get("first_sector") else None,
            "e3_to_free_e7": save["e7"] - save["e3"] if save.get("e7") else None,
            "start_to_free_e7": save["e7"] - save["e1"] if save.get("e7") and save.get("e1") is not None else None,
            "line_frame_minus_e3": line["frame"] - save["e3"] if "frame" in line else None,
            "line_seen_minus_e3": line["seen_at"] - save["e3"] if "seen_at" in line else None,
            "T1_stamp_look_before_freeze": line["frame"] < save["e3"] - 1 if "frame" in line else None,
            "T1_stamp_equals_truth_hm": stamp == (truth.get("play_time") or [None, None])[:2] if stamp else None,
            "stamp": stamp, "truth_play_time": truth.get("play_time"), "line_bytes": line.get("bytes"),
            "full": line.get("full"), "slot_at_e4_equals_truth": save.get("slot_at_e4_equals_truth"),
            "held_free_at_start": (save.get("start") or {}).get("held_free"), "map_at_start": (save.get("start") or {}).get("const"),
            "moment": moment, "before_target": pokedex is None or save["e3"] < pokedex})
    frames = play.get("frames") or 0
    hours = frames / FPS / 3600 if frames else None
    s12 = {f"S{s['save']}": {k: s["truth"].get(k) for k in IDENTITY_KEYS} for s in saves[:2]}
    return {"seed": row["seed"], "reason": play.get("reason"), "frames": frames, "seconds": play.get("seconds"),
            "child_a_seconds": (row.get("child_a") or {}).get("seconds"), "saves": out_saves, "saves_n": len(saves),
            "saves_before_target": sum(1 for s in out_saves if s["before_target"]),
            "game_hours": round(hours, 3) if hours else None,
            "saves_per_game_hour": round(len(saves) / hours, 2) if hours else None,
            "NEW": new_maps(a), "identities": s12, "proof_first": proof_first, "end_save": play.get("end_save"),
            "flash_reads": a.get("flash_reads"), "watched_frames": a.get("frames")}


def continue_numbers(row: dict) -> dict:
    """Step 6 (c)'s numbers for one arm: child B's frames from power-on (the emulator's, by the harness) to the main menu
    taking input, to the CONTINUE press, to the HELD free arrival; the press-to-arrival span; both children's wall times;
    child A's frame at the kill."""
    b = row.get("b") or {}
    press = next((p[0] for p in b.get("presses") or [] if p[1] == "A" and p[2] and p[2][0] == "Task_HandleMainMenuInput"),
                 None)
    arrival = (b.get("arrival") or {}).get("f")
    return {"arm": row["arm"], "seed": row["seed"], "menu_input_from": b.get("menu_input_from"), "continue_press": press,
            "arrival": arrival, "press_to_arrival": arrival - press if arrival is not None and press is not None else None,
            "b_frames_run": b.get("frames"), "child_a_seconds": (row.get("child_a") or {}).get("seconds"),
            "child_b_seconds": (row.get("child_b") or {}).get("seconds"), "kill_frame": ((row.get("a") or {}).get("kill")
                                                                                         or {}).get("frame")}


def cmd_measure(args) -> int:
    rows = sorted(Path(args.out).glob("rows/CONTROL-*.json"))
    out = [measure_row(json.loads(path.read_text(encoding="utf-8"))) for path in rows]
    for item in out:
        print("MEASURE " + json.dumps(item, ensure_ascii=False), flush=True)
    for path in sorted(Path(args.out).glob("rows/K-*.json")):
        print("CONTINUE " + json.dumps(continue_numbers(json.loads(path.read_text(encoding="utf-8")))), flush=True)
    return 0


def cmd_b_again(args) -> int:
    """(development) Run child B again on ITS OWN fresh copy of an arm's FROZEN set (the frozen set is never changed: every
    child B copies it), e.g. after a child-B-side fix; the row keeps the earlier child B under `b_earlier`."""
    path = Path(args.row)
    row = json.loads(path.read_text(encoding="utf-8"))
    ctx = ctx_of(argparse.Namespace(build_root=args.build_root, out=str(path.parents[1])))
    earlier = {key: row.pop(key) for key in ("child_b", "b", "b_memory", "b_run", "grade") if key in row}
    row.setdefault("b_earlier", []).append(earlier)
    run_child_b(ctx, row, Path(row["frozen"]["dir"]), suffix=args.suffix)
    row["grade"] = grade(row)
    path.write_text(json.dumps(row, ensure_ascii=False), encoding="utf-8")
    g = row["grade"]
    print("LIVE ARM " + json.dumps({"arm": row["arm"], "seed": row["seed"], "b": args.suffix,
                                    "file": (row.get("file") or {}).get("verdict"), "counted": g.get("counted"),
                                    "pass": g.get("pass"), "checks": g.get("checks"),
                                    "b_reason": ((row.get("b") or {}).get("play") or {}).get("reason")}, ensure_ascii=False))
    return 0


def cmd_grade(args) -> int:
    for path in args.rows:
        row = json.loads(Path(path).read_text(encoding="utf-8"))
        row["grade"] = grade(row)
        print("GRADE " + json.dumps({"arm": row["arm"], "seed": row["seed"], **row["grade"]}, ensure_ascii=False))
    return 0


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("control", "arm"):
        p = sub.add_parser(name)
        p.add_argument("--seed", type=int, required=True)
        p.add_argument("--out", required=True)
        p.add_argument("--frames", type=int, default=FRAMES_A)
        p.add_argument("--build-root")
        if name == "arm":
            p.add_argument("--arm", required=True, choices=sorted(KILLS))
            p.add_argument("--between-from")
            p.add_argument("--between-rule", choices=("midpoint", "new"), default="midpoint")
            p.add_argument("--tag", help="(development) the row's name instead of the arm's (a variant of an arm)")
    p = sub.add_parser("grade")
    p.add_argument("rows", nargs="+")
    p = sub.add_parser("measure")
    p.add_argument("--out", required=True)
    p = sub.add_parser("b-again")
    p.add_argument("--row", required=True)
    p.add_argument("--suffix", required=True)
    p.add_argument("--build-root")
    p = sub.add_parser("child-a")
    for flag in ("--profile-dir", "--memory", "--kill", "--record", "--run-dir", "--play-json"):
        p.add_argument(flag, required=True)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--frames", type=int, required=True)
    p = sub.add_parser("child-b")
    for flag in ("--profile-dir", "--run-dir", "--play-json"):
        p.add_argument(flag, required=True)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--frames", type=int, default=0)
    args = parser.parse_args()
    if args.cmd == "child-a":
        return child_a(args)
    if args.cmd == "child-b":
        return child_b(args)
    if args.cmd == "control":
        return cmd_control(args)
    if args.cmd == "arm":
        return cmd_arm(args)
    if args.cmd == "measure":
        return cmd_measure(args)
    if args.cmd == "b-again":
        return cmd_b_again(args)
    return cmd_grade(args)


if __name__ == "__main__":
    sys.exit(main())
